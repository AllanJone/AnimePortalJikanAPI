﻿namespace AnimePortalJikanAPI.JikanDecoder.Model.Secondary
{
    public class Seasons
    {
    }
}